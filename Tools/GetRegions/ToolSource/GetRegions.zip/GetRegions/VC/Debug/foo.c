// Automatically generated file. Do not edit if you plan to regenerate it.
#include "region.h"
const REGION_T RegionTable[] = {
	{0x000000c1, 0x000000c8, "__main"}, // 0
	{0x000000c9, 0x000000fc, "__scatterload_rt2"}, // 1
	{0x00000105, 0x0000011e, "__scatterload_copy"}, // 2
	{0x00000121, 0x0000013c, "__scatterload_zeroinit"}, // 3
	{0x00000165, 0x00000170, "Reset_Handler"}, // 4
	{0x00000171, 0x00000172, "NMI_Handler"}, // 5
	{0x00000173, 0x00000174, "HardFault_Handler"}, // 6
	{0x00000175, 0x00000176, "SVC_Handler"}, // 7
	{0x00000177, 0x00000178, "PendSV_Handler"}, // 8
	{0x00000179, 0x0000017a, "SysTick_Handler"}, // 9
	{0x000001a5, 0x000001a6, "__use_two_region_memory"}, // 10
	{0x000001a7, 0x000001a8, "__rt_heap_escrow$2region"}, // 11
	{0x000001a9, 0x000001aa, "__rt_heap_expand$2region"}, // 12
	{0x000001ab, 0x000001e8, "__user_setup_stackheap"}, // 13
	{0x000001e9, 0x000001f8, "exit"}, // 14
	{0x000001f9, 0x00000200, "__user_libspace"}, // 15
	{0x00000201, 0x00000208, "_sys_exit"}, // 16
	{0x0000020d, 0x0000020e, "__use_no_semihosting_swi"}, // 17
	{0x00000211, 0x00000256, "Control_RGB_LEDs"}, // 18
	{0x0000025d, 0x00000332, "Init_Debug_Signals"}, // 19
	{0x00000345, 0x000003c0, "Init_RGB_LEDs"}, // 20
	{0x000003d1, 0x000003de, "SPI_CS_High"}, // 21
	{0x000003e5, 0x000003f2, "SPI_CS_Low"}, // 22
	{0x00000411, 0x000005d0, "SD_Init"}, // 23
	{0x000005d5, 0x00000684, "SD_Read"}, // 24
	{0x0000068d, 0x00000748, "SD_Write"}, // 25
	{0x0000074d, 0x00000754, "SPI_Freq_High"}, // 26
	{0x00000759, 0x00000760, "SPI_Freq_Low"}, // 27
	{0x00000765, 0x000007b0, "SPI_Init"}, // 28
	{0x000007c5, 0x0000080c, "SPI_RW"}, // 29
	{0x00000815, 0x00000830, "SPI_Release"}, // 30
	{0x00000831, 0x00000838, "SPI_Timer_Off"}, // 31
	{0x0000083d, 0x0000085c, "SPI_Timer_On"}, // 32
	{0x00000865, 0x00000870, "SPI_Timer_Status"}, // 33
	{0x00000875, 0x0000097e, "SystemInit"}, // 34
	{0x000009ad, 0x000009c0, "__SD_Power_Of_Two"}, // 35
	{0x000009c1, 0x00000aa6, "__SD_Sectors"}, // 36
	{0x00000aa9, 0x00000b6e, "__SD_Send_Cmd"}, // 37
	{0x00000b75, 0x00000b88, "__SD_Speed_Transfer"}, // 38
	{0x00000b89, 0x00000b9e, "main"}, // 39
	{0x00000ba1, 0x00000d0c, "test_write"}, // 40
}; 
const unsigned NumProfileRegions=41;
volatile unsigned RegionCount[41];
